const express = require("express");
const { connectMongoDB } = require("./Admin/connection");


const vendorRouter = require("./Admin/routes/vendor")
const authRoutes = require('./Auth/routes/auth');
const app = express();
const port = 3000;


//Connection
connectMongoDB("mongodb://127.0.0.1:27017/AdminDB").then(() => 
    console.log("MongoDB Connected!")
);

//middleware to convert object to json
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Routes

// route for /login and /signup
app.use('/api/auth', authRoutes);

// route for venues get and create
app.use("/api/vendor", vendorRouter);

app.listen(port, () => console.log("server started"));

